package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity{
    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    Button button9;
    Button button10;
    Button button11;
    Button button12;
    Button buttonBaixo;
    Button buttonDireita;

    String[][] cuboMagico;
    String[][] cuboMagico2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        button4 = (Button) findViewById(R.id.button4);
        button5 = (Button) findViewById(R.id.button5);
        button6 = (Button) findViewById(R.id.button6);
        button7 = (Button) findViewById(R.id.button7);
        button8 = (Button) findViewById(R.id.button8);
        button9 = (Button) findViewById(R.id.button9);
        button10 = (Button) findViewById(R.id.button10);
        button11 = (Button) findViewById(R.id.button11);
        button12 = (Button) findViewById(R.id.button12);

        buttonBaixo = (Button) findViewById(R.id.buttonBaixo);
        buttonDireita = (Button) findViewById(R.id.buttonDireita);

        cuboMagico = new String[12][12];
        cuboMagico2 = new String[12][12];

        //azul     X  Y
        cuboMagico[0][0] = "azul";
        cuboMagico[1][0] = "azul";
        cuboMagico[2][0] = "azul";

        cuboMagico[0][1] = "azul";
        cuboMagico[1][1] = "azul";
        cuboMagico[2][1] = "azul";

        cuboMagico[0][2] = "azul";
        cuboMagico[1][2] = "azul";
        cuboMagico[2][2] = "azul";
        //--
        //laranja
        cuboMagico[3][0] = "laranja";
        cuboMagico[4][0] = "laranja";
        cuboMagico[5][0] = "laranja";

        cuboMagico[3][1] = "laranja";
        cuboMagico[4][1] = "laranja";
        cuboMagico[5][1] = "laranja";

        cuboMagico[3][2] = "laranja";
        cuboMagico[4][2] = "laranja";
        cuboMagico[5][2] = "laranja";
        //--
        //verde
        cuboMagico[6][0] = "verde";
        cuboMagico[7][0] = "verde";
        cuboMagico[8][0] = "verde";

        cuboMagico[6][1] = "verde";
        cuboMagico[7][1] = "verde";
        cuboMagico[8][1] = "verde";

        cuboMagico[6][2] = "verde";
        cuboMagico[7][2] = "verde";
        cuboMagico[8][2] = "verde";
        //--
        //vermelho
        cuboMagico[9][0]  = "vermelho";
        cuboMagico[10][0] = "vermelho";
        cuboMagico[11][0] = "vermelho";

        cuboMagico[9][1]  = "vermelho";
        cuboMagico[10][1] = "vermelho";
        cuboMagico[11][1] = "vermelho";

        cuboMagico[9][2]  = "vermelho";
        cuboMagico[10][2] = "vermelho";
        cuboMagico[11][2] = "vermelho";
        //--
        //amarelo
        cuboMagico[0][3] = "amarelo";
        cuboMagico[1][3] = "amarelo";
        cuboMagico[2][3] = "amarelo";

        cuboMagico[0][4] = "amarelo";
        cuboMagico[1][4] = "amarelo";
        cuboMagico[2][4] = "amarelo";

        cuboMagico[0][5] = "amarelo";
        cuboMagico[1][5] = "amarelo";
        cuboMagico[2][5] = "amarelo";
        //--
        //preto
        cuboMagico[3][3] = "preto";
        cuboMagico[4][3] = "preto";
        cuboMagico[5][3] = "preto";

        cuboMagico[3][4] = "preto";
        cuboMagico[4][4] = "preto";
        cuboMagico[5][4] = "preto";

        cuboMagico[3][5] = "preto";
        cuboMagico[4][5] = "preto";
        cuboMagico[5][5] = "preto";
        //--
        //preto
        cuboMagico[6][3] = "preto";
        cuboMagico[7][3] = "preto";
        cuboMagico[8][3] = "preto";

        cuboMagico[6][4] = "preto";
        cuboMagico[7][4] = "preto";
        cuboMagico[8][4] = "preto";

        cuboMagico[6][5] = "preto";
        cuboMagico[7][5] = "preto";
        cuboMagico[8][5] = "preto";
        //--
        //preto
        cuboMagico[9][3]  = "preto";
        cuboMagico[10][3] = "preto";
        cuboMagico[11][3] = "preto";

        cuboMagico[9][4]  = "preto";
        cuboMagico[10][4] = "preto";
        cuboMagico[11][4] = "preto";

        cuboMagico[9][5]  = "preto";
        cuboMagico[10][5] = "preto";
        cuboMagico[11][5] = "preto";
        //--
        //verdeY
        cuboMagico[0][6] = cuboMagico[6][0];
        cuboMagico[1][6] = cuboMagico[7][0];
        cuboMagico[2][6] = cuboMagico[8][0];

        cuboMagico[0][7] = cuboMagico[6][1];
        cuboMagico[1][7] = cuboMagico[7][1];
        cuboMagico[2][7] = cuboMagico[8][1];

        cuboMagico[0][8] = cuboMagico[6][2];
        cuboMagico[1][8] = cuboMagico[7][2];
        cuboMagico[2][8] = cuboMagico[8][2];
        //--
        //preto
        cuboMagico[3][6] = "preto";
        cuboMagico[4][6] = "preto";
        cuboMagico[5][6] = "preto";

        cuboMagico[3][7] = "preto";
        cuboMagico[4][7] = "preto";
        cuboMagico[5][7] = "preto";

        cuboMagico[3][8] = "preto";
        cuboMagico[4][8] = "preto";
        cuboMagico[5][8] = "preto";
        //--
        //preto
        cuboMagico[6][6] = "preto";
        cuboMagico[7][6] = "preto";
        cuboMagico[8][6] = "preto";

        cuboMagico[6][7] = "preto";
        cuboMagico[7][7] = "preto";
        cuboMagico[8][7] = "preto";

        cuboMagico[6][8] = "preto";
        cuboMagico[7][8] = "preto";
        cuboMagico[8][8] = "preto";
        //--
        //preto
        cuboMagico[9][6]  = "preto";
        cuboMagico[10][6] = "preto";
        cuboMagico[11][6] = "preto";

        cuboMagico[9][7]  = "preto";
        cuboMagico[10][7] = "preto";
        cuboMagico[11][7] = "preto";

        cuboMagico[9][8]  = "preto";
        cuboMagico[10][8] = "preto";
        cuboMagico[11][8] = "preto";
        //--
        //branco
        cuboMagico[0][9] = "branco";
        cuboMagico[1][9] = "branco";
        cuboMagico[2][9] = "branco";

        cuboMagico[0][10] = "branco";
        cuboMagico[1][10] = "branco";
        cuboMagico[2][10] = "branco";

        cuboMagico[0][11] = "branco";
        cuboMagico[1][11] = "branco";
        cuboMagico[2][11] = "branco";
        //--
        //preto
        cuboMagico[3][9] = "preto";
        cuboMagico[4][9] = "preto";
        cuboMagico[5][9] = "preto";

        cuboMagico[3][10] = "preto";
        cuboMagico[4][10] = "preto";
        cuboMagico[5][10] = "preto";

        cuboMagico[3][11] = "preto";
        cuboMagico[4][11] = "preto";
        cuboMagico[5][11] = "preto";
        //--
        //preto
        cuboMagico[6][9] = "preto";
        cuboMagico[7][9] = "preto";
        cuboMagico[8][9] = "preto";

        cuboMagico[6][10] = "preto";
        cuboMagico[7][10] = "preto";
        cuboMagico[8][10] = "preto";

        cuboMagico[6][11] = "preto";
        cuboMagico[7][11] = "preto";
        cuboMagico[8][11] = "preto";
        //--
        //preto
        cuboMagico[9][9]  = "preto";
        cuboMagico[10][9] = "preto";
        cuboMagico[11][9] = "preto";

        cuboMagico[9][10]  = "preto";
        cuboMagico[10][10] = "preto";
        cuboMagico[11][10] = "preto";

        cuboMagico[9][11]  = "preto";
        cuboMagico[10][11] = "preto";
        cuboMagico[11][11] = "preto";
        //--presente
//----------------------------------------------------------------------------------------------
        //--passado
        //azul     X  Y
        cuboMagico2[0][0] = "azul";
        cuboMagico2[1][0] = "azul";
        cuboMagico2[2][0] = "azul";

        cuboMagico2[0][1] = "azul";
        cuboMagico2[1][1] = "azul";
        cuboMagico2[2][1] = "azul";

        cuboMagico2[0][2] = "azul";
        cuboMagico2[1][2] = "azul";
        cuboMagico2[2][2] = "azul";
        //--
        //laranja
        cuboMagico2[3][0] = "laranja";
        cuboMagico2[4][0] = "laranja";
        cuboMagico2[5][0] = "laranja";

        cuboMagico2[3][1] = "laranja";
        cuboMagico2[4][1] = "laranja";
        cuboMagico2[5][1] = "laranja";

        cuboMagico2[3][2] = "laranja";
        cuboMagico2[4][2] = "laranja";
        cuboMagico2[5][2] = "laranja";
        //--
        //verde
        cuboMagico2[6][0] = "verde";
        cuboMagico2[7][0] = "verde";
        cuboMagico2[8][0] = "verde";

        cuboMagico2[6][1] = "verde";
        cuboMagico2[7][1] = "verde";
        cuboMagico2[8][1] = "verde";

        cuboMagico2[6][2] = "verde";
        cuboMagico2[7][2] = "verde";
        cuboMagico2[8][2] = "verde";
        //--
        //vermelho
        cuboMagico2[9][0]  = "vermelho";
        cuboMagico2[10][0] = "vermelho";
        cuboMagico2[11][0] = "vermelho";

        cuboMagico2[9][1]  = "vermelho";
        cuboMagico2[10][1] = "vermelho";
        cuboMagico2[11][1] = "vermelho";

        cuboMagico2[9][2]  = "vermelho";
        cuboMagico2[10][2] = "vermelho";
        cuboMagico2[11][2] = "vermelho";
        //--
        //amarelo
        cuboMagico2[0][3] = "amarelo";
        cuboMagico2[1][3] = "amarelo";
        cuboMagico2[2][3] = "amarelo";

        cuboMagico2[0][4] = "amarelo";
        cuboMagico2[1][4] = "amarelo";
        cuboMagico2[2][4] = "amarelo";

        cuboMagico2[0][5] = "amarelo";
        cuboMagico2[1][5] = "amarelo";
        cuboMagico2[2][5] = "amarelo";
        //--
        //preto
        cuboMagico2[3][3] = "preto";
        cuboMagico2[4][3] = "preto";
        cuboMagico2[5][3] = "preto";

        cuboMagico2[3][4] = "preto";
        cuboMagico2[4][4] = "preto";
        cuboMagico2[5][4] = "preto";

        cuboMagico2[3][5] = "preto";
        cuboMagico2[4][5] = "preto";
        cuboMagico2[5][5] = "preto";
        //--
        //preto
        cuboMagico2[6][3] = "preto";
        cuboMagico2[7][3] = "preto";
        cuboMagico2[8][3] = "preto";

        cuboMagico2[6][4] = "preto";
        cuboMagico2[7][4] = "preto";
        cuboMagico2[8][4] = "preto";

        cuboMagico2[6][5] = "preto";
        cuboMagico2[7][5] = "preto";
        cuboMagico2[8][5] = "preto";
        //--
        //preto
        cuboMagico2[9][3]  = "preto";
        cuboMagico2[10][3] = "preto";
        cuboMagico2[11][3] = "preto";

        cuboMagico2[9][4]  = "preto";
        cuboMagico2[10][4] = "preto";
        cuboMagico2[11][4] = "preto";

        cuboMagico2[9][5]  = "preto";
        cuboMagico2[10][5] = "preto";
        cuboMagico2[11][5] = "preto";
        //--
        //verdeY
        cuboMagico2[0][6] = cuboMagico2[6][0];
        cuboMagico2[1][6] = cuboMagico2[7][0];
        cuboMagico2[2][6] = cuboMagico2[8][0];

        cuboMagico2[0][7] = cuboMagico2[6][1];
        cuboMagico2[1][7] = cuboMagico2[7][1];
        cuboMagico2[2][7] = cuboMagico2[8][1];

        cuboMagico2[0][8] = cuboMagico2[6][2];
        cuboMagico2[1][8] = cuboMagico2[7][2];
        cuboMagico2[2][8] = cuboMagico2[8][2];
        //--
        //--
        //preto
        cuboMagico2[3][6] = "preto";
        cuboMagico2[4][6] = "preto";
        cuboMagico2[5][6] = "preto";

        cuboMagico2[3][7] = "preto";
        cuboMagico2[4][7] = "preto";
        cuboMagico2[5][7] = "preto";

        cuboMagico2[3][8] = "preto";
        cuboMagico2[4][8] = "preto";
        cuboMagico2[5][8] = "preto";
        //--
        //preto
        cuboMagico2[6][6] = "preto";
        cuboMagico2[7][6] = "preto";
        cuboMagico2[8][6] = "preto";

        cuboMagico2[6][7] = "preto";
        cuboMagico2[7][7] = "preto";
        cuboMagico2[8][7] = "preto";

        cuboMagico2[6][8] = "preto";
        cuboMagico2[7][8] = "preto";
        cuboMagico2[8][8] = "preto";
        //--
        //preto
        cuboMagico2[9][6]  = "preto";
        cuboMagico2[10][6] = "preto";
        cuboMagico2[11][6] = "preto";

        cuboMagico2[9][7]  = "preto";
        cuboMagico2[10][7] = "preto";
        cuboMagico2[11][7] = "preto";

        cuboMagico2[9][8]  = "preto";
        cuboMagico2[10][8] = "preto";
        cuboMagico2[11][8] = "preto";
        //--
        //branco
        cuboMagico2[0][9] = "branco";
        cuboMagico2[1][9] = "branco";
        cuboMagico2[2][9] = "branco";

        cuboMagico2[0][10] = "branco";
        cuboMagico2[1][10] = "branco";
        cuboMagico2[2][10] = "branco";

        cuboMagico2[0][11] = "branco";
        cuboMagico2[1][11] = "branco";
        cuboMagico2[2][11] = "branco";
        //--
        //preto
        cuboMagico2[3][9] = "preto";
        cuboMagico2[4][9] = "preto";
        cuboMagico2[5][9] = "preto";

        cuboMagico2[3][10] = "preto";
        cuboMagico2[4][10] = "preto";
        cuboMagico2[5][10] = "preto";

        cuboMagico2[3][11] = "preto";
        cuboMagico2[4][11] = "preto";
        cuboMagico2[5][11] = "preto";
        //--
        //preto
        cuboMagico2[6][9] = "preto";
        cuboMagico2[7][9] = "preto";
        cuboMagico2[8][9] = "preto";

        cuboMagico2[6][10] = "preto";
        cuboMagico2[7][10] = "preto";
        cuboMagico2[8][10] = "preto";

        cuboMagico2[6][11] = "preto";
        cuboMagico2[7][11] = "preto";
        cuboMagico2[8][11] = "preto";
        //--
        //preto
        cuboMagico2[9][9]  = "preto";
        cuboMagico2[10][9] = "preto";
        cuboMagico2[11][9] = "preto";

        cuboMagico2[9][10]  = "preto";
        cuboMagico2[10][10] = "preto";
        cuboMagico2[11][10] = "preto";

        cuboMagico2[9][11]  = "preto";
        cuboMagico2[10][11] = "preto";
        cuboMagico2[11][11] = "preto";
        //--
    }
    public void um(View view) {
        //X
        //azul
        cuboMagico[0][0] = cuboMagico2[9][0];
        cuboMagico[1][0] = cuboMagico2[10][0];
        cuboMagico[2][0] = cuboMagico2[11][0];
        //--
        //laranja
        cuboMagico[3][0] = cuboMagico2[0][0];
        cuboMagico[4][0] = cuboMagico2[1][0];
        cuboMagico[5][0] = cuboMagico2[2][0];
        //--
        //verde
        cuboMagico[6][0] = cuboMagico2[3][0];
        cuboMagico[7][0] = cuboMagico2[4][0];
        cuboMagico[8][0] = cuboMagico2[5][0];
        //--
        //vermelho
        cuboMagico[9][0] = cuboMagico2[6][0];
        cuboMagico[10][0] = cuboMagico2[7][0];
        cuboMagico[11][0] = cuboMagico2[8][0];
        //--

        //Y
        //branco
        cuboMagico[0][9] = cuboMagico2[2][9] ;
        cuboMagico[1][9] = cuboMagico2[2][10];
        cuboMagico[2][9] = cuboMagico2[2][11];

        cuboMagico[0][10] = cuboMagico2[1][9];
        cuboMagico[1][10] = cuboMagico2[1][10];
        cuboMagico[2][10] = cuboMagico2[1][11];

        cuboMagico[0][11] = cuboMagico2[0][9];
        cuboMagico[1][11] = cuboMagico2[0][10];
        cuboMagico[2][11] = cuboMagico2[0][11];

        cuboMagico2[0][9] = cuboMagico[0][9];
        cuboMagico2[1][9] = cuboMagico[1][9];
        cuboMagico2[2][9] = cuboMagico[2][9];

        cuboMagico2[0][10] = cuboMagico[0][10];
        cuboMagico2[1][10] = cuboMagico[1][10];
        cuboMagico2[2][10] = cuboMagico[2][10];

        cuboMagico2[0][11] = cuboMagico[0][11];
        cuboMagico2[1][11] = cuboMagico[1][11];
        cuboMagico2[2][11] = cuboMagico[2][11];
        //--

        //verdeY
        cuboMagico[0][6] = cuboMagico[8][2];
        cuboMagico[1][6] = cuboMagico[7][2];
        cuboMagico[2][6] = cuboMagico[6][2];

        cuboMagico[0][7] = cuboMagico[8][1];
        cuboMagico[1][7] = cuboMagico[7][1];
        cuboMagico[2][7] = cuboMagico[6][1];

        cuboMagico[0][8] = cuboMagico[8][0];
        cuboMagico[1][8] = cuboMagico[7][0];
        cuboMagico[2][8] = cuboMagico[6][0];

        cuboMagico2[0][6] = cuboMagico[0][6];
        cuboMagico2[1][6] = cuboMagico[1][6];
        cuboMagico2[2][6] = cuboMagico[2][6];

        cuboMagico2[0][7] = cuboMagico[0][7];
        cuboMagico2[1][7] = cuboMagico[1][7];
        cuboMagico2[2][7] = cuboMagico[2][7];

        cuboMagico2[0][8] = cuboMagico[0][8];
        cuboMagico2[1][8] = cuboMagico[1][8];
        cuboMagico2[2][8] = cuboMagico[2][8];

        for(int i = 0; i < 12; i++){
            cuboMagico2[i][0] = cuboMagico[i][0];
            cuboMagico2[0][i] = cuboMagico[0][i];
        }

        //colorir
        if(cuboMagico[0][0]=="azul"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[0][0]=="laranja"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[0][0]=="verde"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[0][0]=="vermelho"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[0][0]=="amarelo"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[0][0]=="preto"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[0][0]=="branco"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[1][0]=="azul"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[1][0]=="laranja"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[1][0]=="verde"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[1][0]=="vermelho"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[1][0]=="amarelo"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[1][0]=="preto"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[1][0]=="branco"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[2][0]=="azul"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[2][0]=="laranja"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[2][0]=="verde"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[2][0]=="vermelho"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[2][0]=="amarelo"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[2][0]=="preto"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[2][0]=="branco"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }
    }

    public void dois(View view) {
        //X
        //azul
        cuboMagico[0][1] = cuboMagico2[9][1];
        cuboMagico[1][1] = cuboMagico2[10][1];
        cuboMagico[2][1] = cuboMagico2[11][1];
        //--
        //laranja
        cuboMagico[3][1] = cuboMagico2[0][1];
        cuboMagico[4][1] = cuboMagico2[1][1];
        cuboMagico[5][1] = cuboMagico2[2][1];
        //--
        //verde
        cuboMagico[6][1] = cuboMagico2[3][1];
        cuboMagico[7][1] = cuboMagico2[4][1];
        cuboMagico[8][1] = cuboMagico2[5][1];
        //--
        //vermelho
        cuboMagico[9][1] = cuboMagico2[6][1];
        cuboMagico[10][1] = cuboMagico2[7][1];
        cuboMagico[11][1] = cuboMagico2[8][1];
        //--

        //Y
        //--
        //verdeY
        cuboMagico[0][6] = cuboMagico[8][2];
        cuboMagico[1][6] = cuboMagico[7][2];
        cuboMagico[2][6] = cuboMagico[6][2];

        cuboMagico[0][7] = cuboMagico[8][1];
        cuboMagico[1][7] = cuboMagico[7][1];
        cuboMagico[2][7] = cuboMagico[6][1];

        cuboMagico[0][8] = cuboMagico[8][0];
        cuboMagico[1][8] = cuboMagico[7][0];
        cuboMagico[2][8] = cuboMagico[6][0];

        cuboMagico2[0][6] = cuboMagico[0][6];
        cuboMagico2[1][6] = cuboMagico[1][6];
        cuboMagico2[2][6] = cuboMagico[2][6];

        cuboMagico2[0][7] = cuboMagico[0][7];
        cuboMagico2[1][7] = cuboMagico[1][7];
        cuboMagico2[2][7] = cuboMagico[2][7];

        cuboMagico2[0][8] = cuboMagico[0][8];
        cuboMagico2[1][8] = cuboMagico[1][8];
        cuboMagico2[2][8] = cuboMagico[2][8];

        for (int i = 0; i < 12; i++) {
            cuboMagico2[i][1] = cuboMagico[i][1];
            cuboMagico2[1][i] = cuboMagico[1][i];
        }

        //colorir
        if(cuboMagico[0][1]=="azul"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[0][1]=="laranja"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[0][1]=="verde"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[0][1]=="vermelho"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[0][1]=="amarelo"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[0][1]=="preto"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[0][1]=="branco"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[1][1]=="azul"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[1][1]=="laranja"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[1][1]=="verde"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[1][1]=="vermelho"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[1][1]=="amarelo"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[1][1]=="preto"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[1][1]=="branco"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[2][1]=="azul"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[2][1]=="laranja"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[2][1]=="verde"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[2][1]=="vermelho"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[2][1]=="amarelo"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[2][1]=="preto"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[2][1]=="branco"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }
    }

    public void tres(View view) {
        //X
        //azul
        cuboMagico[0][2] = cuboMagico2[9][2];
        cuboMagico[1][2] = cuboMagico2[10][2];
        cuboMagico[2][2] = cuboMagico2[11][2];
        //--
        //laranja
        cuboMagico[3][2] = cuboMagico2[0][2];
        cuboMagico[4][2] = cuboMagico2[1][2];
        cuboMagico[5][2] = cuboMagico2[2][2];
        //--
        //verde
        cuboMagico[6][2] = cuboMagico2[3][2];
        cuboMagico[7][2] = cuboMagico2[4][2];
        cuboMagico[8][2] = cuboMagico2[5][2];
        //--
        //vermelho
        cuboMagico[9][2] = cuboMagico2[6][2];
        cuboMagico[10][2] = cuboMagico2[7][2];
        cuboMagico[11][2] = cuboMagico2[8][2];
        //--

        //Y
        //amarelo
        cuboMagico[2][5] = cuboMagico2[2][3];
        cuboMagico[1][5] = cuboMagico2[2][4];
        cuboMagico[0][5] = cuboMagico2[2][5];

        cuboMagico[2][4] = cuboMagico2[1][3];
        cuboMagico[1][4] = cuboMagico2[1][4];
        cuboMagico[0][4] = cuboMagico2[1][5];

        cuboMagico[2][3] = cuboMagico2[0][3];
        cuboMagico[1][3] = cuboMagico2[0][4];
        cuboMagico[0][3] = cuboMagico2[0][5];

        cuboMagico2[2][5] = cuboMagico[2][5];
        cuboMagico2[1][5] = cuboMagico[1][5];
        cuboMagico2[0][5] = cuboMagico[0][5];

        cuboMagico2[2][4] = cuboMagico[2][4];
        cuboMagico2[1][4] = cuboMagico[1][4];
        cuboMagico2[0][4] = cuboMagico[0][4];

        cuboMagico2[2][3] = cuboMagico[2][3];
        cuboMagico2[1][3] = cuboMagico[1][3];
        cuboMagico2[0][3] = cuboMagico[0][3];
        //--
        //verdeY
        cuboMagico[0][6] = cuboMagico[8][2];
        cuboMagico[1][6] = cuboMagico[7][2];
        cuboMagico[2][6] = cuboMagico[6][2];

        cuboMagico[0][7] = cuboMagico[8][1];
        cuboMagico[1][7] = cuboMagico[7][1];
        cuboMagico[2][7] = cuboMagico[6][1];

        cuboMagico[0][8] = cuboMagico[8][0];
        cuboMagico[1][8] = cuboMagico[7][0];
        cuboMagico[2][8] = cuboMagico[6][0];

        cuboMagico2[0][6] = cuboMagico[0][6];
        cuboMagico2[1][6] = cuboMagico[1][6];
        cuboMagico2[2][6] = cuboMagico[2][6];

        cuboMagico2[0][7] = cuboMagico[0][7];
        cuboMagico2[1][7] = cuboMagico[1][7];
        cuboMagico2[2][7] = cuboMagico[2][7];

        cuboMagico2[0][8] = cuboMagico[0][8];
        cuboMagico2[1][8] = cuboMagico[1][8];
        cuboMagico2[2][8] = cuboMagico[2][8];

        for(int i = 0; i < 12; i++){
            cuboMagico2[i][2] = cuboMagico[i][2];
            cuboMagico2[2][i] = cuboMagico[2][i];
        }

        //colorir
        if(cuboMagico[0][2]=="azul"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[0][2]=="laranja"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[0][2]=="verde"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[0][2]=="vermelho"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[0][2]=="amarelo"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[0][2]=="preto"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[0][2]=="branco"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[1][2]=="azul"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[1][2]=="laranja"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[1][2]=="verde"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[1][2]=="vermelho"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[1][2]=="amarelo"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[1][2]=="preto"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[1][2]=="branco"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[2][2]=="azul"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[2][2]=="laranja"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[2][2]=="verde"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[2][2]=="vermelho"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[2][2]=="amarelo"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[2][2]=="preto"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[2][2]=="branco"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }
    }

    public void quatro(View view) {
        //Y
        //azul
        cuboMagico[0][0] = cuboMagico2[0][3];
        cuboMagico[0][1] = cuboMagico2[0][4];
        cuboMagico[0][2] = cuboMagico2[0][5];
        //--
        //amarelo
        cuboMagico[0][3] = cuboMagico2[0][6];
        cuboMagico[0][4] = cuboMagico2[0][7];
        cuboMagico[0][5] = cuboMagico2[0][8];
        //--
        //verdeY
        cuboMagico[0][6] = cuboMagico2[0][9];
        cuboMagico[0][7] = cuboMagico2[0][10];
        cuboMagico[0][8] = cuboMagico2[0][11];
        //--
        //branco
        cuboMagico[0][9] = cuboMagico2[0][0];
        cuboMagico[0][10] = cuboMagico2[0][1];
        cuboMagico[0][11] = cuboMagico2[0][2];
        //--

        //X
        //vermelho
        cuboMagico[9][0] = cuboMagico2[11][0] ;
        cuboMagico[10][0] = cuboMagico2[11][1];
        cuboMagico[11][0] = cuboMagico2[11][2];

        cuboMagico[9][1] = cuboMagico2[10][0];
        cuboMagico[10][1] = cuboMagico2[10][1];
        cuboMagico[11][1] = cuboMagico2[10][2];

        cuboMagico[9][2] = cuboMagico2[9][0];
        cuboMagico[10][2] = cuboMagico2[9][1];
        cuboMagico[11][2] = cuboMagico2[9][2];

        cuboMagico2[9][0] = cuboMagico[9][0] ;
        cuboMagico2[10][0] = cuboMagico[10][0];
        cuboMagico2[11][0] = cuboMagico[11][0];

        cuboMagico2[9][1] = cuboMagico[9][1];
        cuboMagico2[10][1] = cuboMagico[10][1];
        cuboMagico2[11][1] = cuboMagico[11][1];

        cuboMagico2[9][2] = cuboMagico[9][2];
        cuboMagico2[10][2] = cuboMagico[10][2];
        cuboMagico2[11][2] = cuboMagico[11][2];
        //--
        //verde
        cuboMagico[6][0] = cuboMagico[2][8];
        cuboMagico[7][0] = cuboMagico[1][8];
        cuboMagico[8][0] = cuboMagico[0][8];

        cuboMagico[6][1] = cuboMagico[2][7];
        cuboMagico[7][1] = cuboMagico[1][7];
        cuboMagico[8][1] = cuboMagico[0][7];

        cuboMagico[6][2] = cuboMagico[2][6];
        cuboMagico[7][2] = cuboMagico[1][6];
        cuboMagico[8][2] = cuboMagico[0][6];

        cuboMagico2[6][0] = cuboMagico[6][0];
        cuboMagico2[7][0] = cuboMagico[7][0];
        cuboMagico2[8][0] = cuboMagico[8][0];

        cuboMagico2[6][1] = cuboMagico[6][1];
        cuboMagico2[7][1] = cuboMagico[7][1];
        cuboMagico2[8][1] = cuboMagico[8][1];

        cuboMagico2[6][2] = cuboMagico[6][2];
        cuboMagico2[7][2] = cuboMagico[7][2];
        cuboMagico2[8][2] = cuboMagico[8][2];
        //--

        for(int i = 0; i < 12; i++){
            cuboMagico2[i][0] = cuboMagico[i][0];
            cuboMagico2[0][i] = cuboMagico[0][i];
        }

        //colorir
        if(cuboMagico[0][0]=="azul"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[0][0]=="laranja"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[0][0]=="verde"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[0][0]=="vermelho"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[0][0]=="amarelo"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[0][0]=="preto"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[0][0]=="branco"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[0][1]=="azul"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[0][1]=="laranja"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[0][1]=="verde"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[0][1]=="vermelho"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[0][1]=="amarelo"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[0][1]=="preto"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[0][1]=="branco"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[0][2]=="azul"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[0][2]=="laranja"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[0][2]=="verde"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[0][2]=="vermelho"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[0][2]=="amarelo"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[0][2]=="preto"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[0][2]=="branco"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }


    }
    public void cinco(View view) {
        //Y
        //azul
        cuboMagico[1][0] = cuboMagico2[1][3];
        cuboMagico[1][1] = cuboMagico2[1][4];
        cuboMagico[1][2] = cuboMagico2[1][5];
        //--
        //amarelo
        cuboMagico[1][3] = cuboMagico2[1][6];
        cuboMagico[1][4] = cuboMagico2[1][7];
        cuboMagico[1][5] = cuboMagico2[1][8];
        //--
        //verdeY
        cuboMagico[1][6] = cuboMagico2[1][9];
        cuboMagico[1][7] = cuboMagico2[1][10];
        cuboMagico[1][8] = cuboMagico2[1][11];
        //--
        //branco
        cuboMagico[1][9] = cuboMagico2[1][0];
        cuboMagico[1][10] = cuboMagico2[1][1];
        cuboMagico[1][11] = cuboMagico2[1][2];
        //--

        //X
        //verde
        cuboMagico[6][0] = cuboMagico[2][8];
        cuboMagico[7][0] = cuboMagico[1][8];
        cuboMagico[8][0] = cuboMagico[0][8];

        cuboMagico[6][1] = cuboMagico[2][7];
        cuboMagico[7][1] = cuboMagico[1][7];
        cuboMagico[8][1] = cuboMagico[0][7];

        cuboMagico[6][2] = cuboMagico[2][6];
        cuboMagico[7][2] = cuboMagico[1][6];
        cuboMagico[8][2] = cuboMagico[0][6];

        cuboMagico2[6][0] = cuboMagico[6][0];
        cuboMagico2[7][0] = cuboMagico[7][0];
        cuboMagico2[8][0] = cuboMagico[8][0];

        cuboMagico2[6][1] = cuboMagico[6][1];
        cuboMagico2[7][1] = cuboMagico[7][1];
        cuboMagico2[8][1] = cuboMagico[8][1];

        cuboMagico2[6][2] = cuboMagico[6][2];
        cuboMagico2[7][2] = cuboMagico[7][2];
        cuboMagico2[8][2] = cuboMagico[8][2];
        //--

        for(int i = 0; i < 12; i++){
            cuboMagico2[i][1] = cuboMagico[i][1];
            cuboMagico2[1][i] = cuboMagico[1][i];
        }
        //colorir
        if(cuboMagico[1] [0]=="azul"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[1][0]=="laranja"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[1][0]=="verde"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[1][0]=="vermelho"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[1][0]=="amarelo"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[1][0]=="preto"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[1][0]=="branco"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[1][1]=="azul"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[1][1]=="laranja"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[1][1]=="verde"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[1][1]=="vermelho"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[1][1]=="amarelo"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[1][1]=="preto"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[1][1]=="branco"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[1][2]=="azul"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[1][2]=="laranja"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[1][2]=="verde"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[1][2]=="vermelho"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[1][2]=="amarelo"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[1][2]=="preto"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[1][2]=="branco"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

    }
    public void seis(View view) {
        //Y
        //azul
        cuboMagico[2][0] = cuboMagico2[2][3];
        cuboMagico[2][1] = cuboMagico2[2][4];
        cuboMagico[2][2] = cuboMagico2[2][5];
        //--
        //amarelo
        cuboMagico[2][3] = cuboMagico2[2][6];
        cuboMagico[2][4] = cuboMagico2[2][7];
        cuboMagico[2][5] = cuboMagico2[2][8];
        //--
        //verdeY
        cuboMagico[2][6] = cuboMagico2[2][9];
        cuboMagico[2][7] = cuboMagico2[2][10];
        cuboMagico[2][8] = cuboMagico2[2][11];
        //--
        //branco
        cuboMagico[2][9] = cuboMagico2[2][0];
        cuboMagico[2][10] = cuboMagico2[2][1];
        cuboMagico[2][11] = cuboMagico2[2][2];
        //--

        //X
        //laranja
        cuboMagico[5][2] = cuboMagico2[5][0];
        cuboMagico[4][2] = cuboMagico2[5][1];
        cuboMagico[3][2] = cuboMagico2[5][2];

        cuboMagico[5][1] = cuboMagico2[4][0];
        cuboMagico[4][1] = cuboMagico2[4][1];
        cuboMagico[3][1] = cuboMagico2[4][2];

        cuboMagico[5][0] = cuboMagico2[3][0];
        cuboMagico[4][0] = cuboMagico2[3][1];
        cuboMagico[3][0] = cuboMagico2[3][2];

        cuboMagico2[5][2] = cuboMagico[5][2];
        cuboMagico2[4][2] = cuboMagico[4][2];
        cuboMagico2[3][2] = cuboMagico[3][2];

        cuboMagico2[5][1] = cuboMagico[5][1];
        cuboMagico2[4][1] = cuboMagico[4][1];
        cuboMagico2[3][1] = cuboMagico[3][1];

        cuboMagico2[5][0] = cuboMagico[5][0];
        cuboMagico2[4][0] = cuboMagico[4][0];
        cuboMagico2[3][0] = cuboMagico[3][0];
        //--
        //verde
        cuboMagico[6][0] = cuboMagico[2][8];
        cuboMagico[7][0] = cuboMagico[1][8];
        cuboMagico[8][0] = cuboMagico[0][8];

        cuboMagico[6][1] = cuboMagico[2][7];
        cuboMagico[7][1] = cuboMagico[1][7];
        cuboMagico[8][1] = cuboMagico[0][7];

        cuboMagico[6][2] = cuboMagico[2][6];
        cuboMagico[7][2] = cuboMagico[1][6];
        cuboMagico[8][2] = cuboMagico[0][6];

        cuboMagico2[6][0] = cuboMagico[6][0];
        cuboMagico2[7][0] = cuboMagico[7][0];
        cuboMagico2[8][0] = cuboMagico[8][0];

        cuboMagico2[6][1] = cuboMagico[6][1];
        cuboMagico2[7][1] = cuboMagico[7][1];
        cuboMagico2[8][1] = cuboMagico[8][1];

        cuboMagico2[6][2] = cuboMagico[6][2];
        cuboMagico2[7][2] = cuboMagico[7][2];
        cuboMagico2[8][2] = cuboMagico[8][2];
        //--

        for(int i = 0; i < 12; i++){
            cuboMagico2[i][2] = cuboMagico[i][2];
            cuboMagico2[2][i] = cuboMagico[2][i];
        }
        //colorir
        if(cuboMagico[2] [0]=="azul"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[2][0]=="laranja"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[2][0]=="verde"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[2][0]=="vermelho"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[2][0]=="amarelo"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[2][0]=="preto"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[2][0]=="branco"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[2][1]=="azul"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[2][1]=="laranja"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[2][1]=="verde"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[2][1]=="vermelho"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[2][1]=="amarelo"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[2][1]=="preto"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[2][1]=="branco"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[2][2]=="azul"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[2][2]=="laranja"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[2][2]=="verde"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[2][2]=="vermelho"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[2][2]=="amarelo"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[2][2]=="preto"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[2][2]=="branco"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

    }

    public void sete(View view) {
        //X
        //azul
        cuboMagico[0][2] = cuboMagico2[3][2];
        cuboMagico[1][2] = cuboMagico2[4][2];
        cuboMagico[2][2] = cuboMagico2[5][2];
        //--
        //laranja
        cuboMagico[3][2] = cuboMagico2[6][2];
        cuboMagico[4][2] = cuboMagico2[7][2];
        cuboMagico[5][2] = cuboMagico2[8][2];
        //--
        //verde
        cuboMagico[6][2] = cuboMagico2[9][2];
        cuboMagico[7][2] = cuboMagico2[10][2];
        cuboMagico[8][2] = cuboMagico2[11][2];
        //--
        //vermelho
        cuboMagico[9][2] = cuboMagico2[0][2];
        cuboMagico[10][2] = cuboMagico2[1][2];
        cuboMagico[11][2] = cuboMagico2[2][2];
        //--

        //Y
        //amarelo
        cuboMagico[0][3] = cuboMagico2[2][3];
        cuboMagico[1][3] = cuboMagico2[2][4];
        cuboMagico[2][3] = cuboMagico2[2][5];

        cuboMagico[0][4] = cuboMagico2[1][3];
        cuboMagico[1][4] = cuboMagico2[1][4];
        cuboMagico[2][4] = cuboMagico2[1][5];

        cuboMagico[0][5] = cuboMagico2[0][3];
        cuboMagico[1][5] = cuboMagico2[0][4];
        cuboMagico[2][5] = cuboMagico2[0][5];

        cuboMagico2[0][3] = cuboMagico[0][3];
        cuboMagico2[1][3] = cuboMagico[1][3];
        cuboMagico2[2][3] = cuboMagico[2][3];

        cuboMagico2[0][4] = cuboMagico[0][4];
        cuboMagico2[1][4] = cuboMagico[1][4];
        cuboMagico2[2][4] = cuboMagico[2][4];

        cuboMagico2[0][5] = cuboMagico[0][5];
        cuboMagico2[1][5] = cuboMagico[1][5];
        cuboMagico2[2][5] = cuboMagico[2][5];
        //--
        //verdeY
        cuboMagico[0][6] = cuboMagico[8][2];
        cuboMagico[1][6] = cuboMagico[7][2];
        cuboMagico[2][6] = cuboMagico[6][2];

        cuboMagico[0][7] = cuboMagico[8][1];
        cuboMagico[1][7] = cuboMagico[7][1];
        cuboMagico[2][7] = cuboMagico[6][1];

        cuboMagico[0][8] = cuboMagico[8][0];
        cuboMagico[1][8] = cuboMagico[7][0];
        cuboMagico[2][8] = cuboMagico[6][0];

        cuboMagico2[0][6] = cuboMagico[0][6];
        cuboMagico2[1][6] = cuboMagico[1][6];
        cuboMagico2[2][6] = cuboMagico[2][6];

        cuboMagico2[0][7] = cuboMagico[0][7];
        cuboMagico2[1][7] = cuboMagico[1][7];
        cuboMagico2[2][7] = cuboMagico[2][7];

        cuboMagico2[0][8] = cuboMagico[0][8];
        cuboMagico2[1][8] = cuboMagico[1][8];
        cuboMagico2[2][8] = cuboMagico[2][8];

        for(int i = 0; i < 12; i++){
            cuboMagico2[i][2] = cuboMagico[i][2];
            cuboMagico2[2][i] = cuboMagico[2][i];
        }
        //colorir
        if(cuboMagico[0][2]=="azul"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[0][2]=="laranja"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[0][2]=="verde"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[0][2]=="vermelho"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[0][2]=="amarelo"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[0][2]=="preto"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[0][2]=="branco"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[1][2]=="azul"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[1][2]=="laranja"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[1][2]=="verde"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[1][2]=="vermelho"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[1][2]=="amarelo"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[1][2]=="preto"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[1][2]=="branco"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[2][2]=="azul"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[2][2]=="laranja"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[2][2]=="verde"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[2][2]=="vermelho"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[2][2]=="amarelo"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[2][2]=="preto"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[2][2]=="branco"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

    }

    public void oito(View view) {
        //X
        //azul
        cuboMagico[0][1] = cuboMagico2[3][1];
        cuboMagico[1][1] = cuboMagico2[4][1];
        cuboMagico[2][1] = cuboMagico2[5][1];
        //--
        //laranja
        cuboMagico[3][1] = cuboMagico2[6][1];
        cuboMagico[4][1] = cuboMagico2[7][1];
        cuboMagico[5][1] = cuboMagico2[8][1];
        //--
        //verde
        cuboMagico[6][1] = cuboMagico2[9][1];
        cuboMagico[7][1] = cuboMagico2[10][1];
        cuboMagico[8][1] = cuboMagico2[11][1];
        //--
        //vermelho
        cuboMagico[9][1] = cuboMagico2[0][1];
        cuboMagico[10][1] = cuboMagico2[1][1];
        cuboMagico[11][1] = cuboMagico2[2][1];
        //--

        //Y
        //--
        //verdeY
        cuboMagico[0][6] = cuboMagico[8][2];
        cuboMagico[1][6] = cuboMagico[7][2];
        cuboMagico[2][6] = cuboMagico[6][2];

        cuboMagico[0][7] = cuboMagico[8][1];
        cuboMagico[1][7] = cuboMagico[7][1];
        cuboMagico[2][7] = cuboMagico[6][1];

        cuboMagico[0][8] = cuboMagico[8][0];
        cuboMagico[1][8] = cuboMagico[7][0];
        cuboMagico[2][8] = cuboMagico[6][0];

        cuboMagico2[0][6] = cuboMagico[0][6];
        cuboMagico2[1][6] = cuboMagico[1][6];
        cuboMagico2[2][6] = cuboMagico[2][6];

        cuboMagico2[0][7] = cuboMagico[0][7];
        cuboMagico2[1][7] = cuboMagico[1][7];
        cuboMagico2[2][7] = cuboMagico[2][7];

        cuboMagico2[0][8] = cuboMagico[0][8];
        cuboMagico2[1][8] = cuboMagico[1][8];
        cuboMagico2[2][8] = cuboMagico[2][8];

        for(int i = 0; i < 12; i++){
            cuboMagico2[i][1] = cuboMagico[i][1];
            cuboMagico2[1][i] = cuboMagico[1][i];
        }
        //colorir
        if(cuboMagico[0][1]=="azul"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[0][1]=="laranja"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[0][1]=="verde"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[0][1]=="vermelho"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[0][1]=="amarelo"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[0][1]=="preto"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[0][1]=="branco"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[1][1]=="azul"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[1][1]=="laranja"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[1][1]=="verde"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[1][1]=="vermelho"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[1][1]=="amarelo"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[1][1]=="preto"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[1][1]=="branco"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[2][1]=="azul"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[2][1]=="laranja"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[2][1]=="verde"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[2][1]=="vermelho"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[2][1]=="amarelo"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[2][1]=="preto"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[2][1]=="branco"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

    }

    public void nove(View view) {
        //X
        //azul
        cuboMagico[0][0] = cuboMagico2[3][0];
        cuboMagico[1][0] = cuboMagico2[4][0];
        cuboMagico[2][0] = cuboMagico2[5][0];
        //--
        //laranja
        cuboMagico[3][0] = cuboMagico2[6][0];
        cuboMagico[4][0] = cuboMagico2[7][0];
        cuboMagico[5][0] = cuboMagico2[8][0];
        //--
        //verde
        cuboMagico[6][0] = cuboMagico2[9][0];
        cuboMagico[7][0] = cuboMagico2[10][0];
        cuboMagico[8][0] = cuboMagico2[11][0];
        //--
        //vermelho
        cuboMagico[9][0] = cuboMagico2[0][0];
        cuboMagico[10][0] = cuboMagico2[1][0];
        cuboMagico[11][0] = cuboMagico2[2][0];
        //--

        //Y
        //branco
        cuboMagico[2][11] = cuboMagico2[2][9] ;
        cuboMagico[1][11] = cuboMagico2[2][10];
        cuboMagico[0][11] = cuboMagico2[2][11];

        cuboMagico[2][10] = cuboMagico2[1][9];
        cuboMagico[1][10] = cuboMagico2[1][10];
        cuboMagico[0][10] = cuboMagico2[1][11];

        cuboMagico[2][9] = cuboMagico2[0][9];
        cuboMagico[1][9] = cuboMagico2[0][10];
        cuboMagico[0][9] = cuboMagico2[0][11];

        cuboMagico2[2][11] = cuboMagico[2][11];
        cuboMagico2[1][11] = cuboMagico[1][11];
        cuboMagico2[0][11] = cuboMagico[0][11];

        cuboMagico2[2][10] = cuboMagico[2][10];
        cuboMagico2[1][10] = cuboMagico[1][10];
        cuboMagico2[0][10] = cuboMagico[0][10];

        cuboMagico2[2][9] = cuboMagico[2][9];
        cuboMagico2[1][9] = cuboMagico[1][9];
        cuboMagico2[0][9] = cuboMagico[0][9];
        //--
        //verdeY
        cuboMagico[0][6] = cuboMagico[8][2];
        cuboMagico[1][6] = cuboMagico[7][2];
        cuboMagico[2][6] = cuboMagico[6][2];

        cuboMagico[0][7] = cuboMagico[8][1];
        cuboMagico[1][7] = cuboMagico[7][1];
        cuboMagico[2][7] = cuboMagico[6][1];

        cuboMagico[0][8] = cuboMagico[8][0];
        cuboMagico[1][8] = cuboMagico[7][0];
        cuboMagico[2][8] = cuboMagico[6][0];

        cuboMagico2[0][6] = cuboMagico[0][6];
        cuboMagico2[1][6] = cuboMagico[1][6];
        cuboMagico2[2][6] = cuboMagico[2][6];

        cuboMagico2[0][7] = cuboMagico[0][7];
        cuboMagico2[1][7] = cuboMagico[1][7];
        cuboMagico2[2][7] = cuboMagico[2][7];

        cuboMagico2[0][8] = cuboMagico[0][8];
        cuboMagico2[1][8] = cuboMagico[1][8];
        cuboMagico2[2][8] = cuboMagico[2][8];

        for(int i = 0; i < 12; i++){
            cuboMagico2[i][0] = cuboMagico[i][0];
            cuboMagico2[0][i] = cuboMagico[0][i];
        }
        //colorir
        if(cuboMagico[0][0]=="azul"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[0][0]=="laranja"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[0][0]=="verde"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[0][0]=="vermelho"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[0][0]=="amarelo"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[0][0]=="preto"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[0][0]=="branco"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[1][0]=="azul"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[1][0]=="laranja"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[1][0]=="verde"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[1][0]=="vermelho"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[1][0]=="amarelo"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[1][0]=="preto"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[1][0]=="branco"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[2][0]=="azul"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[2][0]=="laranja"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[2][0]=="verde"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[2][0]=="vermelho"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[2][0]=="amarelo"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[2][0]=="preto"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[2][0]=="branco"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }
    }

    public void dez(View view) {
        //Y
        //azul
        cuboMagico[2][0] = cuboMagico2[2][9];
        cuboMagico[2][1] = cuboMagico2[2][10];
        cuboMagico[2][2] = cuboMagico2[2][11];
        //--
        //amarelo
        cuboMagico[2][3] = cuboMagico2[2][0];
        cuboMagico[2][4] = cuboMagico2[2][1];
        cuboMagico[2][5] = cuboMagico2[2][2];
        //--
        //verdeY
        cuboMagico[2][6] = cuboMagico2[2][3];
        cuboMagico[2][7] = cuboMagico2[2][4];
        cuboMagico[2][8] = cuboMagico2[2][5];
        //--
        //branco
        cuboMagico[2][9] = cuboMagico2[2][6];
        cuboMagico[2][10] = cuboMagico2[2][7];
        cuboMagico[2][11] = cuboMagico2[2][8];
        //--

        //X
        //laranja
        cuboMagico[3][0] = cuboMagico2[5][0];
        cuboMagico[4][0] = cuboMagico2[5][1];
        cuboMagico[5][0] = cuboMagico2[5][2];

        cuboMagico[3][1] = cuboMagico2[4][0];
        cuboMagico[4][1] = cuboMagico2[4][1];
        cuboMagico[5][1] = cuboMagico2[4][2];

        cuboMagico[3][2] = cuboMagico2[3][0];
        cuboMagico[4][2] = cuboMagico2[3][1];
        cuboMagico[5][2] = cuboMagico2[3][2];

        cuboMagico2[3][0] = cuboMagico[3][0];
        cuboMagico2[4][0] = cuboMagico[4][0];
        cuboMagico2[5][0] = cuboMagico[5][0];

        cuboMagico2[3][1] = cuboMagico[3][1];
        cuboMagico2[4][1] = cuboMagico[4][1];
        cuboMagico2[5][1] = cuboMagico[5][1];

        cuboMagico2[3][2] = cuboMagico[3][2];
        cuboMagico2[4][2] = cuboMagico[4][2];
        cuboMagico2[5][2] = cuboMagico[5][2];
        //--
        //verde
        cuboMagico[6][0] = cuboMagico[2][8];
        cuboMagico[7][0] = cuboMagico[1][8];
        cuboMagico[8][0] = cuboMagico[0][8];

        cuboMagico[6][1] = cuboMagico[2][7];
        cuboMagico[7][1] = cuboMagico[1][7];
        cuboMagico[8][1] = cuboMagico[0][7];

        cuboMagico[6][2] = cuboMagico[2][6];
        cuboMagico[7][2] = cuboMagico[1][6];
        cuboMagico[8][2] = cuboMagico[0][6];

        cuboMagico2[6][0] = cuboMagico[6][0];
        cuboMagico2[7][0] = cuboMagico[7][0];
        cuboMagico2[8][0] = cuboMagico[8][0];

        cuboMagico2[6][1] = cuboMagico[6][1];
        cuboMagico2[7][1] = cuboMagico[7][1];
        cuboMagico2[8][1] = cuboMagico[8][1];

        cuboMagico2[6][2] = cuboMagico[6][2];
        cuboMagico2[7][2] = cuboMagico[7][2];
        cuboMagico2[8][2] = cuboMagico[8][2];
        //--

        for(int i = 0; i < 12; i++){
            cuboMagico2[i][2] = cuboMagico[i][2];
            cuboMagico2[2][i] = cuboMagico[2][i];
        }
        //colorir
        if(cuboMagico[2] [0]=="azul"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[2][0]=="laranja"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[2][0]=="verde"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[2][0]=="vermelho"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[2][0]=="amarelo"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[2][0]=="preto"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[2][0]=="branco"){
            View minhaView3 = findViewById(R.id.textView3);
            minhaView3.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[2][1]=="azul"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[2][1]=="laranja"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[2][1]=="verde"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[2][1]=="vermelho"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[2][1]=="amarelo"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[2][1]=="preto"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[2][1]=="branco"){
            View minhaView6 = findViewById(R.id.textView6);
            minhaView6.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[2][2]=="azul"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[2][2]=="laranja"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[2][2]=="verde"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[2][2]=="vermelho"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[2][2]=="amarelo"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[2][2]=="preto"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[2][2]=="branco"){
            View minhaView9 = findViewById(R.id.textView9);
            minhaView9.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

    }

    public void onze(View view) {
        //Y
        //azul
        cuboMagico[1][0] = cuboMagico2[1][9];
        cuboMagico[1][1] = cuboMagico2[1][10];
        cuboMagico[1][2] = cuboMagico2[1][11];
        //--
        //amarelo
        cuboMagico[1][3] = cuboMagico2[1][0];
        cuboMagico[1][4] = cuboMagico2[1][1];
        cuboMagico[1][5] = cuboMagico2[1][2];
        //--
        //verdeY
        cuboMagico[1][6] = cuboMagico2[1][3];
        cuboMagico[1][7] = cuboMagico2[1][4];
        cuboMagico[1][8] = cuboMagico2[1][5];
        //--
        //branco
        cuboMagico[1][9] = cuboMagico2[1][6];
        cuboMagico[1][10] = cuboMagico2[1][7];
        cuboMagico[1][11] = cuboMagico2[1][8];
        //--

        //X
        //verde
        cuboMagico[6][0] = cuboMagico[2][8];
        cuboMagico[7][0] = cuboMagico[1][8];
        cuboMagico[8][0] = cuboMagico[0][8];

        cuboMagico[6][1] = cuboMagico[2][7];
        cuboMagico[7][1] = cuboMagico[1][7];
        cuboMagico[8][1] = cuboMagico[0][7];

        cuboMagico[6][2] = cuboMagico[2][6];
        cuboMagico[7][2] = cuboMagico[1][6];
        cuboMagico[8][2] = cuboMagico[0][6];

        cuboMagico2[6][0] = cuboMagico[6][0];
        cuboMagico2[7][0] = cuboMagico[7][0];
        cuboMagico2[8][0] = cuboMagico[8][0];

        cuboMagico2[6][1] = cuboMagico[6][1];
        cuboMagico2[7][1] = cuboMagico[7][1];
        cuboMagico2[8][1] = cuboMagico[8][1];

        cuboMagico2[6][2] = cuboMagico[6][2];
        cuboMagico2[7][2] = cuboMagico[7][2];
        cuboMagico2[8][2] = cuboMagico[8][2];
        //--

        for(int i = 0; i < 12; i++){
            cuboMagico2[i][1] = cuboMagico[i][1];
            cuboMagico2[1][i] = cuboMagico[1][i];
        }
        //colorir
        if(cuboMagico[1] [0]=="azul"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[1][0]=="laranja"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[1][0]=="verde"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[1][0]=="vermelho"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[1][0]=="amarelo"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[1][0]=="preto"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[1][0]=="branco"){
            View minhaView2 = findViewById(R.id.textView2);
            minhaView2.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[1][1]=="azul"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[1][1]=="laranja"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[1][1]=="verde"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[1][1]=="vermelho"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[1][1]=="amarelo"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[1][1]=="preto"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[1][1]=="branco"){
            View minhaView5 = findViewById(R.id.textView5);
            minhaView5.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[1][2]=="azul"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[1][2]=="laranja"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[1][2]=="verde"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[1][2]=="vermelho"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[1][2]=="amarelo"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[1][2]=="preto"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[1][2]=="branco"){
            View minhaView8 = findViewById(R.id.textView8);
            minhaView8.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }


    }

    public void doze(View view) {
        //Y
        //azul
        cuboMagico[0][0] = cuboMagico2[0][9];
        cuboMagico[0][1] = cuboMagico2[0][10];
        cuboMagico[0][2] = cuboMagico2[0][11];
        //--
        //amarelo
        cuboMagico[0][3] = cuboMagico2[0][0];
        cuboMagico[0][4] = cuboMagico2[0][1];
        cuboMagico[0][5] = cuboMagico2[0][2];
        //--
        //verdeY
        cuboMagico[0][6] = cuboMagico2[0][3];
        cuboMagico[0][7] = cuboMagico2[0][4];
        cuboMagico[0][8] = cuboMagico2[0][5];
        //--
        //branco
        cuboMagico[0][9] = cuboMagico2[0][6];
        cuboMagico[0][10] = cuboMagico2[0][7];
        cuboMagico[0][11] = cuboMagico2[0][8];
        //--

        //X
        //vermelho
        cuboMagico[11][2] = cuboMagico2[11][0] ;
        cuboMagico[10][2] = cuboMagico2[11][1];
        cuboMagico[9][2] = cuboMagico2[11][2];

        cuboMagico[11][1] = cuboMagico2[10][0];
        cuboMagico[10][1] = cuboMagico2[10][1];
        cuboMagico[9][1] = cuboMagico2[10][2];

        cuboMagico[11][0] = cuboMagico2[9][0];
        cuboMagico[10][0] = cuboMagico2[9][1];
        cuboMagico[9][0] = cuboMagico2[9][2];

        cuboMagico2[11][2] = cuboMagico[11][2] ;
        cuboMagico2[10][2] = cuboMagico[10][2];
        cuboMagico2[9][2] = cuboMagico[9][2];

        cuboMagico2[11][1] = cuboMagico[11][1];
        cuboMagico2[10][1] = cuboMagico[10][1];
        cuboMagico2[9][1] = cuboMagico[9][1];

        cuboMagico2[11][0] = cuboMagico[11][0];
        cuboMagico2[10][0] = cuboMagico[10][0];
        cuboMagico2[9][0] = cuboMagico[9][0];
        //--
        //verde
        cuboMagico[6][0] = cuboMagico[2][8];
        cuboMagico[7][0] = cuboMagico[1][8];
        cuboMagico[8][0] = cuboMagico[0][8];

        cuboMagico[6][1] = cuboMagico[2][7];
        cuboMagico[7][1] = cuboMagico[1][7];
        cuboMagico[8][1] = cuboMagico[0][7];

        cuboMagico[6][2] = cuboMagico[2][6];
        cuboMagico[7][2] = cuboMagico[1][6];
        cuboMagico[8][2] = cuboMagico[0][6];

        cuboMagico2[6][0] = cuboMagico[6][0];
        cuboMagico2[7][0] = cuboMagico[7][0];
        cuboMagico2[8][0] = cuboMagico[8][0];

        cuboMagico2[6][1] = cuboMagico[6][1];
        cuboMagico2[7][1] = cuboMagico[7][1];
        cuboMagico2[8][1] = cuboMagico[8][1];

        cuboMagico2[6][2] = cuboMagico[6][2];
        cuboMagico2[7][2] = cuboMagico[7][2];
        cuboMagico2[8][2] = cuboMagico[8][2];
        //--

        for(int i = 0; i < 12; i++){
            cuboMagico2[i][0] = cuboMagico[i][0];
            cuboMagico2[0][i] = cuboMagico[0][i];
        }
        //colorir
        if(cuboMagico[0][0]=="azul"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[0][0]=="laranja"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[0][0]=="verde"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[0][0]=="vermelho"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[0][0]=="amarelo"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[0][0]=="preto"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[0][0]=="branco"){
            View minhaView1 = findViewById(R.id.textView1);
            minhaView1.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[0][1]=="azul"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[0][1]=="laranja"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[0][1]=="verde"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[0][1]=="vermelho"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[0][1]=="amarelo"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[0][1]=="preto"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[0][1]=="branco"){
            View minhaView4 = findViewById(R.id.textView4);
            minhaView4.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

        if(cuboMagico[0][2]=="azul"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#2196F3"));
        }else if(cuboMagico[0][2]=="laranja"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#FF9800"));
        }else if(cuboMagico[0][2]=="verde"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#8BC34A"));
        }else if(cuboMagico[0][2]=="vermelho"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#F44336"));
        }else if(cuboMagico[0][2]=="amarelo"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#FFEB3B"));
        }else if(cuboMagico[0][2]=="preto"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#000000"));
        }else if(cuboMagico[0][2]=="branco"){
            View minhaView7 = findViewById(R.id.textView7);
            minhaView7.setBackgroundColor(Color.parseColor("#E3E3E2"));
        }

    }

    public void baixo(View view) {
        quatro(view);
        cinco(view);
        seis(view);
    }
    public void direita(View view) {
        sete(view);
        oito(view);
        nove(view);
    }

}